Survey
======
A survey system wrote in php and based on framework CodeIgniter and BootStrap  
一款基于PHP的问卷调查系统  
  
Backstage：CodeIgniter (http://codeigniter.org.cn/user_guide/index.html)  
Front：BootStrap (http://www.bootcss.com/)  

Demo Address：http://166.111.74.44/survey
